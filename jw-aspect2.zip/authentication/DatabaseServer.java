public class DatabaseServer {
    public void connect() {
	System.out.println("Connecting");
    }
}
