public class Test {
    public static void main(String[] args) {
	HelloWorld.say("Hello World");
	HelloWorld.sayToPerson("How are you?", "Tom");
    }
}
